﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookHF.Entities
{
    public class Book
    {
        [Key]
        public int Id { get; set; }
        [StringLength(255)]
        public string Title { get; set; }
        public DateTime PublishedDate { get; set; }
        [ForeignKey("Author")]
        public int AuthorId { get; set; }
    }
}
