﻿using BookHF.Context;
using BookHF.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController(BookContext _context) : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var books = await _context.Books.ToListAsync();
            return Ok(books);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var book = await _context.Books.FirstOrDefaultAsync(book => book.Id == id);
            if (book is null)
            {
                return NotFound();
            }

            return Ok(book);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Book book)
        {
            await _context.Books.AddAsync(book);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = book.Id }, book);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Book updatedBook)
        {
            var bookToUpdate = await _context.Books.FirstOrDefaultAsync(book => book.Id == id);
            if (bookToUpdate is null)
            {
                return NotFound();
            }

            bookToUpdate.Title = updatedBook.Title;
            bookToUpdate.PublishedDate = updatedBook.PublishedDate;
            bookToUpdate.AuthorId = updatedBook.AuthorId;

            await _context.SaveChangesAsync();
            return NoContent();
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var bookToDelete = await _context.Books.FirstOrDefaultAsync(book => book.Id == id);
            if (bookToDelete is null)
            {
                return NotFound();
            }

            _context.Books.Remove(bookToDelete);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
