﻿using BookHF.Entities;
using Microsoft.EntityFrameworkCore;

namespace BookHF.Context
{
    public class BookContext(DbContextOptions options) : DbContext(options)
    {
        public DbSet<Book> Books { get; set; }
    }
}
